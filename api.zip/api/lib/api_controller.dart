import 'package:flutter/material.dart';

class ApiController extends ChangeNotifier {
  double lat = 0.0;
  double long = 0.0;
  String erro = '';

  ApiController() {
    getPosicao();
  }

  getPosicao() async {
    try {
      Position posicao = await _posicaoAtual();
      lat = posicao.latitude;
      long = posicao.longitude;
    } catch (e) {
      erro = e.toString();
    }
    notifyListeners();
  }

  Future<Position> _posicaoAtual() async {
    LocationPermission permissao;
  }
}
