import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('API'),
      ),
      body: ChangeNotifierProvider<ApiController>();
      Create:(context) => ApiController(),
    );
  }
}

// class MapScreen extends StatefulWidget {
//   MapScreen({Key? key}) : super(key: key);
//   @override
//   _MapScreenState createState() => _MapScreenState();
// }

// class _MapScreenState extends State<MapScreen> {
// static const _initialCameraPosition = CameraPosition(
// target:LatLng(-19.912998, -43.940933),
// zoom: 2,  
// );

// class _MapScreenState extends State<MapScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body:MapScreen(
//         initialCameraPosition:
//       ),
//     );
//   }
// }



//class MyHomePage extends StatefulWidget {
  //const MyHomePage({Key? key, required this.title}) : super(key: key);

//  final String title;

 // @override
 // State<MyHomePage> createState() => _MyHomePageState();
//}

//class _MyHomePageState extends State<MyHomePage> {
 // @override
//  Widget build(BuildContext context) {
   // return Scaffold(
//       body: Center(
//         child: Column(children: <Widget>[
//           Expanded(
//             child: Container(
//               color: Colors.black,
//               child: Container(
//                 color: Colors.blue,
//               ),
//             ),
//           )
//         ]),
//       ),
//       // This trailing comma makes auto-formatting nicer for build methods.
//     );
//   }
// }
 // children: [Image(image: AssetImage('/assets/images/maple.png'),)]
      //      body: Center(
      //   child: Column(
      //     children: <Widget>[
      //       Expanded(
      //         child: Container(
      //         color: Colors.black,
      //         ),
      //       ),
      //       Expanded(
      //         child: Container(
      //           color: Colors.red,
              
      //         ),
      //       ),
      //       Expanded(
      //         child: Container(
      //         color: Colors.yellow,
             
            
      //     )
      //   ],
      //   ),
      // ),
